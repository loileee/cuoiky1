package quanlycapphatthuoc;
//Lớp Bệnh nhân
class BenhNhan {
 private String maBenhNhan;
 private String tenBenhNhan;
 private int tuoi;

 public BenhNhan(String maBenhNhan, String tenBenhNhan, int tuoi) {
     this.maBenhNhan = maBenhNhan;
     this.tenBenhNhan = tenBenhNhan;
     this.tuoi = tuoi;
 }

 public String getMaBenhNhan() {
     return maBenhNhan;
 }

 public String getTenBenhNhan() {
     return tenBenhNhan;
 }

 public int getTuoi() {
     return tuoi;
 }

 @Override
 public String toString() {
     return "Mã bệnh nhân: " + maBenhNhan + ", Tên: " + tenBenhNhan + ", Tuổi: " + tuoi;
 }
}

//Lớp Nhân viên
class NhanVien {
 private String maNhanVien;
 private String tenNhanVien;

 public NhanVien(String maNhanVien, String tenNhanVien) {
     this.maNhanVien = maNhanVien;
     this.tenNhanVien = tenNhanVien;
 }

 public String getMaNhanVien() {
     return maNhanVien;
 }

 public String getTenNhanVien() {
     return tenNhanVien;
 }

 @Override
 public String toString() {
     return "Mã nhân viên: " + maNhanVien + ", Tên: " + tenNhanVien;
 }
}

//Lớp Thuốc
class Thuoc {
 private String maThuoc;
 private String tenThuoc;
 private int soLuongTon;

 public Thuoc(String maThuoc, String tenThuoc, int soLuongTon) {
     this.maThuoc = maThuoc;
     this.tenThuoc = tenThuoc;
     this.soLuongTon = soLuongTon;
 }

 public String getMaThuoc() {
     return maThuoc;
 }

 public String getTenThuoc() {
     return tenThuoc;
 }

 public int getSoLuongTon() {
     return soLuongTon;
 }

 public void capNhatSoLuong(int soLuong) {
     this.soLuongTon -= soLuong;
 }

 @Override
 public String toString() {
     return "Mã thuốc: " + maThuoc + ", Tên: " + tenThuoc + ", Số lượng tồn: " + soLuongTon;
 }
}

//Lớp Cấp phát thuốc
class CapPhatThuoc {
 private BenhNhan benhNhan;
 private NhanVien nhanVien;
 private Thuoc thuoc;
 private int soLuong;

 public CapPhatThuoc(BenhNhan benhNhan, NhanVien nhanVien, Thuoc thuoc, int soLuong) {
     this.benhNhan = benhNhan;
     this.nhanVien = nhanVien;
     this.thuoc = thuoc;
     this.soLuong = soLuong;
 }

 public void thucHienCapPhat() {
     if (thuoc.getSoLuongTon() >= soLuong) {
         thuoc.capNhatSoLuong(soLuong);
         System.out.println("Cấp phát thành công: " + soLuong + " " + thuoc.getTenThuoc() + 
             " cho bệnh nhân " + benhNhan.getTenBenhNhan());
     } else {
         System.out.println("Không đủ thuốc để cấp phát.");
     }
 }

 @Override
 public String toString() {
     return "Bệnh nhân: " + benhNhan.getTenBenhNhan() + ", Nhân viên: " + nhanVien.getTenNhanVien() + 
             ", Thuốc: " + thuoc.getTenThuoc() + ", Số lượng: " + soLuong;
 }
}

//Lớp Lịch sử cấp phát
class LichSuCapPhat {
 private List<CapPhatThuoc> danhSachCapPhat;

 public LichSuCapPhat() {
     danhSachCapPhat = new ArrayList<>();
 }

 public void themCapPhat(CapPhatThuoc capPhat) {
     danhSachCapPhat.add(capPhat);
 }

 public void hienThiLichSu() {
     System.out.println("--- Lịch sử cấp phát ---");
     for (CapPhatThuoc capPhat : danhSachCapPhat) {
         System.out.println(capPhat);
     }
 }
}

//Lớp Main
import java.util.ArrayList;
import java.util.List;

public class quanly {
 public static void main(String[] args) {
     BenhNhan benhNhan1 = new BenhNhan("BN01", "Nguyen Van A", 30);
     NhanVien nhanVien1 = new NhanVien("NV01", "Le Thi B");
     Thuoc thuoc1 = new Thuoc("T01", "Paracetamol", 100);

     CapPhatThuoc capPhat1 = new CapPhatThuoc(benhNhan1, nhanVien1, thuoc1, 10);
     LichSuCapPhat lichSu = new LichSuCapPhat();

     capPhat1.thucHienCapPhat();
     lichSu.themCapPhat(capPhat1);

     lichSu.hienThiLichSu();
 }
}


