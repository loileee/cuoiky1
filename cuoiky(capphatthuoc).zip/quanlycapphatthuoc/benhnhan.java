package quanlycapphatthuoc;

public class benhnhan {
	    private String maBenhNhan;
	    private String hoTen;
	    private int tuoi;
	    private String diaChi;

	    public benhnhan(String maBenhNhan, String hoTen, int tuoi, String diaChi) {
	        this.maBenhNhan = maBenhNhan;
	        this.hoTen = hoTen;
	        this.tuoi = tuoi;
	        this.diaChi = diaChi;
	    }

	    public String getMaBenhNhan() {
	        return maBenhNhan;
	    }

	    public void setMaBenhNhan(String maBenhNhan) {
	        this.maBenhNhan = maBenhNhan;
	    }

	    public String getHoTen() {
	        return hoTen;
	    }

	    public void setHoTen(String hoTen) {
	        this.hoTen = hoTen;
	    }

	    public int getTuoi() {
	        return tuoi;
	    }

	    public void setTuoi(int tuoi) {
	        this.tuoi = tuoi;
	    }

	    public String getDiaChi() {
	        return diaChi;
	    }

	    public void setDiaChi(String diaChi) {
	        this.diaChi = diaChi;
	    }
	    public static void main(String[] args) {
	    	benhnhan bn= new benhnhan("1","Nguyen Van A",30,"Ha Noi");
	    	System.out.println("tên bệnh nhân:"+ bn.getHoTen());
	    	
	    }
}
	

	