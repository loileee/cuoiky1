package quanlycapphatthuoc;

public class thuoc {
	
	    private String maThuoc;
	    private String tenThuoc;
	    private String donViTinh;
	    private double gia;

	    public thuoc(String maThuoc, String tenThuoc, String donViTinh, double gia) {
	        this.maThuoc = maThuoc;
	        this.tenThuoc = tenThuoc;
	        this.donViTinh = donViTinh;
	        this.gia = gia;
	    }

	    public String getMaThuoc() {
	        return maThuoc;
	    }

	    public void setMaThuoc(String maThuoc) {
	        this.maThuoc = maThuoc;
	    }

	    public String getTenThuoc() {
	        return tenThuoc;
	    }

	    public void setTenThuoc(String tenThuoc) {
	        this.tenThuoc = tenThuoc;
	    }

	    public String getDonViTinh() {
	        return donViTinh;
	    }

	    public void setDonViTinh(String donViTinh) {
	        this.donViTinh = donViTinh;
	    }

	    public double getGia() {
	        return gia;
	    }

	    public void setGia(double gia) {
	        this.gia = gia;
	    }
	}

	